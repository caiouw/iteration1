/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kuripotcoders_valorantgunstore;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author kardamo
 */
public class KuripotCoders_ValorantGunStore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        new Store();
    }
}
